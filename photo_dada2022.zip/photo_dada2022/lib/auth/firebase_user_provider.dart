import 'package:firebase_auth/firebase_auth.dart';
import 'package:rxdart/rxdart.dart';

class PhotoDada2022FirebaseUser {
  PhotoDada2022FirebaseUser(this.user);
  User user;
  bool get loggedIn => user != null;
}

PhotoDada2022FirebaseUser currentUser;
bool get loggedIn => currentUser?.loggedIn ?? false;
Stream<PhotoDada2022FirebaseUser> photoDada2022FirebaseUserStream() =>
    FirebaseAuth.instance
        .authStateChanges()
        .debounce((user) => user == null && !loggedIn
            ? TimerStream(true, const Duration(seconds: 1))
            : Stream.value(user))
        .map<PhotoDada2022FirebaseUser>(
            (user) => currentUser = PhotoDada2022FirebaseUser(user));
