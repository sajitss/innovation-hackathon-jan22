import '../../flutter_flow/flutter_flow_util.dart';

import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

class MetGetDepartmentsCall {
  static Future<ApiCallResponse> call({
    int departmentId,
    String q = 'cat',
  }) {
    return ApiManager.instance.makeApiCall(
      callName: 'metGetDepartments',
      apiUrl:
          'https://collectionapi.metmuseum.org/public/collection/v1/search?departmentId=6&q=cat',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'departmentId': departmentId,
        'q': q,
      },
      returnBody: true,
    );
  }
}

class MwtGetAllDepartmentsCall {
  static Future<ApiCallResponse> call() {
    return ApiManager.instance.makeApiCall(
      callName: 'mwtGetAllDepartments',
      apiUrl:
          'https://collectionapi.metmuseum.org/public/collection/v1/departments',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
    );
  }
}

class PhotoDadaDetectItemsCall {
  static Future<ApiCallResponse> call({
    String imageurl =
        'https://images.indianexpress.com/2020/09/Amitabh-Ban-1.jpg',
  }) {
    return ApiManager.instance.makeApiCall(
      callName: 'photoDadaDetectItems',
      apiUrl: 'http://photodada.com:5000/app1/detectObjects',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'imageurl': imageurl,
      },
      returnBody: true,
    );
  }
}
