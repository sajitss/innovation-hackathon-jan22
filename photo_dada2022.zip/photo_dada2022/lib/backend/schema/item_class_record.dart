import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'item_class_record.g.dart';

abstract class ItemClassRecord
    implements Built<ItemClassRecord, ItemClassRecordBuilder> {
  static Serializer<ItemClassRecord> get serializer =>
      _$itemClassRecordSerializer;

  @nullable
  String get name;

  @nullable
  @BuiltValueField(wireName: 'name_hindi')
  String get nameHindi;

  @nullable
  @BuiltValueField(wireName: 'name_tamil')
  String get nameTamil;

  @nullable
  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference get reference;

  static void _initializeBuilder(ItemClassRecordBuilder builder) => builder
    ..name = ''
    ..nameHindi = ''
    ..nameTamil = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('item_class');

  static Stream<ItemClassRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s)));

  static Future<ItemClassRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s)));

  ItemClassRecord._();
  factory ItemClassRecord([void Function(ItemClassRecordBuilder) updates]) =
      _$ItemClassRecord;

  static ItemClassRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference});
}

Map<String, dynamic> createItemClassRecordData({
  String name,
  String nameHindi,
  String nameTamil,
}) =>
    serializers.toFirestore(
        ItemClassRecord.serializer,
        ItemClassRecord((i) => i
          ..name = name
          ..nameHindi = nameHindi
          ..nameTamil = nameTamil));
