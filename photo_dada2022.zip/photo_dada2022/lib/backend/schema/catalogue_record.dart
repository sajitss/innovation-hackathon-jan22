import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'catalogue_record.g.dart';

abstract class CatalogueRecord
    implements Built<CatalogueRecord, CatalogueRecordBuilder> {
  static Serializer<CatalogueRecord> get serializer =>
      _$catalogueRecordSerializer;

  @nullable
  String get name;

  @nullable
  DocumentReference get owner;

  @nullable
  String get picture;

  @nullable
  String get outlet;

  @nullable
  @BuiltValueField(wireName: 'create_time')
  DateTime get createTime;

  @nullable
  String get addressline;

  @nullable
  LatLng get gpslocation;

  @nullable
  BuiltList<DocumentReference> get items;

  @nullable
  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference get reference;

  static void _initializeBuilder(CatalogueRecordBuilder builder) => builder
    ..name = ''
    ..picture = ''
    ..outlet = ''
    ..addressline = ''
    ..items = ListBuilder();

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('catalogue');

  static Stream<CatalogueRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s)));

  static Future<CatalogueRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s)));

  CatalogueRecord._();
  factory CatalogueRecord([void Function(CatalogueRecordBuilder) updates]) =
      _$CatalogueRecord;

  static CatalogueRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference});
}

Map<String, dynamic> createCatalogueRecordData({
  String name,
  DocumentReference owner,
  String picture,
  String outlet,
  DateTime createTime,
  String addressline,
  LatLng gpslocation,
}) =>
    serializers.toFirestore(
        CatalogueRecord.serializer,
        CatalogueRecord((c) => c
          ..name = name
          ..owner = owner
          ..picture = picture
          ..outlet = outlet
          ..createTime = createTime
          ..addressline = addressline
          ..gpslocation = gpslocation
          ..items = null));
